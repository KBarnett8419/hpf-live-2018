<?php
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/sanitization-functions/sanitize-checkbox.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/sanitization-functions/sanitize-color.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/sanitization-functions/sanitize-email.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/sanitization-functions/sanitize-image.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/sanitization-functions/sanitize-upload.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/sanitization-functions/sanitize-number.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/sanitization-functions/sanitize-post.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/sanitization-functions/sanitize-range.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/sanitization-functions/sanitize-select.php';